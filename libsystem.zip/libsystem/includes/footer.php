<footer class="main-footer " style='background-color:black;border-top:1px solid;text-align:center'>
    <div class="container" >
      <!-- <div class="pull-right hidden-xs">
        <b>Open Admin Panel and Add/View user to know Login ID</b>
      </div> -->
      <strong style="color:white;"><i>&copy; 2020 - NARC LIBRARY || Made By &nbsp;&nbsp;<a href=""> NASIRU</a></i></strong>
      </div>
    <!-- /.container -->
</footer>