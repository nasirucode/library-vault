<footer class="main-footer">
    <div class="pull-right hidden-xs">
     
    </div>
    <strong>&copy; 2020 - Library Management System | Brought To You By <a href="">Nasiru</a></strong>
</footer>